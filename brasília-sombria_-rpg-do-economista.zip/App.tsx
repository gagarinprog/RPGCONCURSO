import React, { useState } from 'react';
import { GameState, Quest } from './types';
import { generateQuest } from './services/geminiService';
import { BattleArena } from './components/BattleArena';
import { Button } from './components/Button';
import { BookOpen, Sparkles, Trophy, Skull, RefreshCw, Map } from 'lucide-react';

const TOPICS = [
  "Inflação e Regimes de Metas",
  "Política Fiscal e Teto de Gastos",
  "Setor Externo e Balanço de Pagamentos",
  "Estrutura de Mercado (Oligopólios)",
  "Contabilidade Social e PIB",
  "Sistema Financeiro Nacional"
];

const App: React.FC = () => {
  const [gameState, setGameState] = useState<GameState>(GameState.MENU);
  const [currentTopic, setCurrentTopic] = useState<string | null>(null);
  const [stage, setStage] = useState(1);
  const [currentQuest, setCurrentQuest] = useState<Quest | null>(null);
  const [loadingMsg, setLoadingMsg] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  const startCampaign = async (topic: string) => {
    setCurrentTopic(topic);
    setStage(1);
    await loadStage(topic, 1);
  };

  const loadStage = async (topic: string, stageNumber: number) => {
    setGameState(GameState.LOADING);
    const isBoss = stageNumber % 11 === 0;
    
    if (isBoss) {
        setLoadingMsg(`ALERTA: O GUARDIÃO DO ESTÁGIO ${stageNumber} SE APROXIMA...`);
    } else {
        setLoadingMsg(`Viajando para o Estágio ${stageNumber}: Explorando ${topic}...`);
    }
    
    setErrorMsg("");
    
    try {
      // Pass stage number to generate appropriate content
      const quest = await generateQuest(topic, stageNumber);
      setCurrentQuest(quest);
      setGameState(GameState.COMBAT);
    } catch (err) {
      console.error(err);
      setErrorMsg("O portal para a Torre do Tesouro falhou. A Legião do Desconhecimento bloqueou a conexão.");
      setGameState(GameState.ERROR);
    }
  };

  const handleVictory = () => {
    // If it was a boss battle (Stage 11, 22, etc), show Big Victory Screen
    if (stage % 11 === 0) {
      setGameState(GameState.VICTORY);
    } else {
      // Automatically advance to next stage map/menu
      setGameState(GameState.CAMPAIGN_MAP);
    }
  };

  const nextStage = () => {
    if (currentTopic) {
      const nextStageNum = stage + 1;
      setStage(nextStageNum);
      loadStage(currentTopic, nextStageNum);
    }
  };

  const handleDefeat = () => setGameState(GameState.DEFEAT);
  
  const resetGame = () => {
    setCurrentQuest(null);
    setCurrentTopic(null);
    setStage(1);
    setGameState(GameState.MENU);
  };

  const retryStage = () => {
    if (currentTopic) {
      loadStage(currentTopic, stage);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-200 selection:bg-purple-500 selection:text-white pb-12">
      
      {/* Background Texture */}
      <div className="fixed inset-0 opacity-5 pointer-events-none z-0" 
           style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%239C92AC' fill-opacity='0.4'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")` }}>
      </div>

      <div className="relative z-10">
        {/* Navbar */}
        <nav className="border-b border-slate-800 bg-slate-900/50 backdrop-blur-md sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
            <div className="flex items-center gap-2 cursor-pointer" onClick={resetGame}>
              <BookOpen className="text-purple-500 w-6 h-6" />
              <span className="font-bold text-lg rpg-font tracking-wider text-slate-100">Brasília Sombria</span>
            </div>
            <div className="flex items-center gap-4">
              {currentTopic && (
                 <span className="text-xs md:text-sm font-bold bg-slate-800 px-3 py-1 rounded text-purple-300 border border-purple-500/30">
                    {currentTopic}
                 </span>
              )}
              <div className="text-xs text-slate-500 font-mono hidden md:block">
                Cebraspe Protocol: ACTIVE
              </div>
            </div>
          </div>
        </nav>

        {/* MENU STATE */}
        {gameState === GameState.MENU && (
          <div className="max-w-4xl mx-auto px-4 mt-16 animate-fade-in">
            <div className="text-center mb-16">
              <h1 className="text-5xl md:text-7xl font-extrabold mb-6 text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-amber-400 rpg-font drop-shadow-sm">
                A Jornada do Economista
              </h1>
              <p className="text-xl text-slate-400 max-w-2xl mx-auto leading-relaxed">
                Bem-vindo à <span className="text-purple-400 font-bold">Brasília Sombria</span>. 
                Escolha seu campo de batalha. Cada tópico possui 10 estágios preparatórios e um <span className="text-red-400 font-bold">Boss Final (30 Questões)</span>.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {TOPICS.map((topic) => (
                <button
                  key={topic}
                  onClick={() => startCampaign(topic)}
                  className="group relative p-6 bg-slate-900 border border-slate-700 hover:border-purple-500 rounded-lg transition-all duration-300 hover:shadow-[0_0_20px_rgba(168,85,247,0.2)] text-left"
                >
                  <div className="absolute top-0 right-0 p-3 opacity-0 group-hover:opacity-100 transition-opacity">
                    <Sparkles className="w-5 h-5 text-amber-400" />
                  </div>
                  <h3 className="text-lg font-bold text-slate-200 group-hover:text-purple-300 mb-2">{topic}</h3>
                  <p className="text-sm text-slate-500">Campanha Longa</p>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* LOADING STATE */}
        {gameState === GameState.LOADING && (
          <div className="flex flex-col items-center justify-center min-h-[60vh]">
            <div className="w-20 h-20 border-4 border-purple-900 border-t-purple-400 rounded-full animate-spin mb-8 shadow-[0_0_30px_rgba(168,85,247,0.3)]"></div>
            <h2 className="text-2xl font-bold text-purple-300 animate-pulse rpg-font text-center px-4">{loadingMsg}</h2>
            <p className="text-slate-500 mt-4 animate-bounce">Materializando pesadelos...</p>
          </div>
        )}

        {/* ERROR STATE */}
        {gameState === GameState.ERROR && (
          <div className="flex flex-col items-center justify-center min-h-[60vh] text-center px-4">
            <div className="text-red-500 mb-6">
              <Skull className="w-20 h-20" />
            </div>
            <h2 className="text-3xl font-bold text-red-500 mb-4 rpg-font">Erro Crítico</h2>
            <p className="text-slate-300 mb-8 max-w-md">{errorMsg}</p>
            <Button onClick={retryStage} variant="secondary">
              Tentar Novamente
            </Button>
          </div>
        )}

        {/* CAMPAIGN MAP (Between Stages) */}
        {gameState === GameState.CAMPAIGN_MAP && (
          <div className="max-w-2xl mx-auto px-4 mt-16 text-center animate-fade-in">
             <div className="mb-8">
                <Map className="w-16 h-16 text-amber-500 mx-auto mb-4" />
                <h2 className="text-3xl font-bold text-amber-500 rpg-font">Vitória! O caminho se abre.</h2>
                <p className="text-slate-300 mt-2">Você sobreviveu ao estágio {stage}.</p>
             </div>
             
             <div className="bg-slate-900 border border-slate-700 p-8 rounded-lg mb-8">
                <div className="flex justify-between items-center mb-2">
                   <span className="text-sm text-slate-400">Progresso do Tópico</span>
                   <span className="text-sm font-bold text-purple-400">{stage} / 11 (BOSS)</span>
                </div>
                <div className="w-full h-4 bg-slate-800 rounded-full overflow-hidden">
                   <div 
                     className="h-full bg-purple-600 transition-all duration-500" 
                     style={{ width: `${(stage / 11) * 100}%` }}
                   ></div>
                </div>
                <p className="text-xs text-slate-500 mt-4 italic">
                   {stage === 10 ? "Prepare-se... O chefe final está próximo." : "Continue avançando para dominar este tópico."}
                </p>
             </div>

             <Button onClick={nextStage} fullWidth className="text-xl py-6">
                {stage === 10 ? "ENFRENTAR O BOSS (30 QUESTÕES)" : "Avançar para Próximo Estágio"}
             </Button>
          </div>
        )}

        {/* COMBAT STATE */}
        {gameState === GameState.COMBAT && currentQuest && (
          <BattleArena 
            quest={currentQuest} 
            onVictory={handleVictory}
            onDefeat={handleDefeat}
          />
        )}

        {/* VICTORY STATE (BOSS DEFEATED) */}
        {gameState === GameState.VICTORY && currentQuest && (
          <div className="flex flex-col items-center justify-center min-h-[70vh] text-center px-4 animate-fade-in">
            <div className="mb-8 relative">
              <div className="absolute inset-0 bg-amber-500 blur-3xl opacity-20 rounded-full"></div>
              <Trophy className="w-32 h-32 text-amber-400 relative z-10 drop-shadow-[0_0_15px_rgba(251,191,36,0.5)]" />
            </div>
            <h2 className="text-5xl font-bold text-amber-400 mb-4 rpg-font">TÓPICO DOMINADO!</h2>
            <p className="text-xl text-slate-300 mb-8 max-w-xl mx-auto">
              A lendária besta <span className="text-red-400 font-bold">{currentQuest.boss.name}</span> caiu. 
              Você provou seu valor para a INFRA S.A.
            </p>
            
            {currentQuest.imageUrl && (
              <div className="mb-8 rounded-lg overflow-hidden border-2 border-amber-500 max-w-md w-full shadow-lg opacity-50 grayscale hover:grayscale-0 transition-all duration-500">
                <img src={currentQuest.imageUrl} alt="Monstro Derrotado" className="w-full h-48 object-cover" />
              </div>
            )}

            <div className="flex gap-4">
               <Button onClick={resetGame} variant="secondary">
                 Menu Principal
               </Button>
               <Button onClick={nextStage} variant="primary">
                 Continuar Jornada (Próximo Ciclo)
               </Button>
            </div>
          </div>
        )}

        {/* DEFEAT STATE */}
        {gameState === GameState.DEFEAT && currentQuest && (
          <div className="flex flex-col items-center justify-center min-h-[70vh] text-center px-4 animate-fade-in">
             <div className="mb-8 relative">
              <div className="absolute inset-0 bg-red-600 blur-3xl opacity-20 rounded-full"></div>
              <Skull className="w-32 h-32 text-red-500 relative z-10" />
            </div>
            <h2 className="text-5xl font-bold text-red-500 mb-4 rpg-font">Derrota</h2>
            <p className="text-xl text-slate-300 mb-8 max-w-lg">
              Você caiu no estágio {stage}. Estude mais e tente novamente.
            </p>
            
            <Button onClick={retryStage} variant="danger" className="px-12 py-4 text-xl flex items-center gap-2">
              <RefreshCw className="w-5 h-5" /> Tentar Novamente
            </Button>
            <div className="mt-4">
              <button onClick={resetGame} className="text-slate-500 hover:text-slate-300 underline">
                Voltar ao Menu
              </button>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};

export default App;