import { GoogleGenAI, Type } from "@google/genai";
import { Quest } from "../types";

// Initialize Gemini Client
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const SYSTEM_INSTRUCTION_BASE = `
Você é o Mestre de um RPG "Brasília Sombria". 
Cenário: Brasília pós-apocalíptica onde conceitos econômicos viraram monstros.
Público: Concurseiros de Elite (Nível CEBRASPE Hard).
`;

const RESPONSE_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    quest_id: { type: Type.STRING },
    quest_title: { type: Type.STRING },
    environment_desc: { type: Type.STRING },
    boss: {
      type: Type.OBJECT,
      properties: {
        name: { type: Type.STRING },
        visual_archetype: { type: Type.STRING },
        hp: { type: Type.NUMBER },
        weakness: { type: Type.STRING },
        special_ability: { type: Type.STRING },
      },
      required: ["name", "visual_archetype", "hp", "weakness", "special_ability"]
    },
    combat_rounds: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          round_id: { type: Type.NUMBER },
          narrative: { type: Type.STRING },
          question: {
            type: Type.OBJECT,
            properties: {
              statement: { type: Type.STRING },
              type: { type: Type.STRING, enum: ["CERTO_ERRADO"] },
              correct_answer: { type: Type.STRING, enum: ["CERTO", "ERRADO"] },
              damage_on_hit: { type: Type.NUMBER },
              damage_on_miss: { type: Type.NUMBER },
              explanation: { type: Type.STRING },
            },
            required: ["statement", "type", "correct_answer", "damage_on_hit", "damage_on_miss", "explanation"]
          }
        },
        required: ["round_id", "narrative", "question"]
      }
    },
    loot: {
      type: Type.OBJECT,
      properties: {
        item_name: { type: Type.STRING },
        xp_reward: { type: Type.NUMBER },
      },
      required: ["item_name", "xp_reward"]
    }
  },
  required: ["quest_id", "quest_title", "environment_desc", "boss", "combat_rounds", "loot"]
};

// Function to generate the visual representation of the enemy/scene
async function generateSceneImage(description: string, entityName: string): Promise<string | undefined> {
  try {
    const prompt = `Dark fantasy concept art, rpg style, high quality, ominous atmosphere. A monster representing ${entityName}. Scene: ${description}. Digital art, trending on artstation.`;
    
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: { parts: [{ text: prompt }] },
      config: {
        imageConfig: { aspectRatio: "16:9" }
      }
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
  } catch (e) {
    console.warn("Failed to generate image:", e);
    return undefined; // Graceful fallback
  }
  return undefined;
}

export const generateQuest = async (topic: string, stage: number): Promise<Quest> => {
  const isBoss = stage % 11 === 0; // Stage 11 is Boss (assuming 10 stages before it)
  
  // Difficulty scaling
  const difficulty = isBoss ? "EXTREMA (Nível Final de Concurso)" : "DIFÍCIL (Simulado Avançado)";
  const rounds = isBoss ? 5 : 1; // Boss has more rounds (simulating the 30 questions gauntlet in a condensed form for web viability)
  
  try {
    const prompt = `
      Gere um encontro de RPG para o estágio ${stage} do tópico "${topic}".
      ${isBoss ? "ESTE É O CHEFE DA FASE. Crie um monstro lendário." : "Este é um monstro comum (minion)."}
      Dificuldade da Questão: ${difficulty}.
      Quantidade de Rounds/Questões: ${rounds}.
      ${isBoss ? "O monstro deve ter muito HP." : "O monstro tem HP normal."}
    `;

    // 1. Generate Text Content
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION_BASE,
        responseMimeType: "application/json",
        responseSchema: RESPONSE_SCHEMA,
      }
    });

    if (!response.text) throw new Error("No text generated");
    const questData = JSON.parse(response.text) as Quest;

    // 2. Generate Image Content based on the generated text
    const imagePrompt = `${questData.boss.visual_archetype} in ${questData.environment_desc}`;
    const imageUrl = await generateSceneImage(imagePrompt, questData.boss.name);

    return {
      ...questData,
      imageUrl,
      is_boss_battle: isBoss,
      stage_number: stage
    };

  } catch (error) {
    console.error("Failed to generate quest:", error);
    throw error;
  }
};