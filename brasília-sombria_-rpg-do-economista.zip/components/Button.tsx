import React from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'danger' | 'success';
  fullWidth?: boolean;
}

export const Button: React.FC<ButtonProps> = ({ 
  children, 
  variant = 'primary', 
  fullWidth = false, 
  className = '', 
  ...props 
}) => {
  const baseStyles = "relative px-6 py-3 font-bold uppercase tracking-wider transition-all duration-200 transform hover:-translate-y-1 active:translate-y-0 disabled:opacity-50 disabled:cursor-not-allowed border-2 rpg-font shadow-lg";
  
  const variants = {
    primary: "bg-purple-900 border-purple-500 text-purple-100 hover:bg-purple-800 hover:shadow-purple-500/50",
    secondary: "bg-slate-800 border-slate-500 text-slate-300 hover:bg-slate-700 hover:shadow-slate-500/50",
    danger: "bg-red-900 border-red-500 text-red-100 hover:bg-red-800 hover:shadow-red-500/50",
    success: "bg-emerald-900 border-emerald-500 text-emerald-100 hover:bg-emerald-800 hover:shadow-emerald-500/50",
  };

  return (
    <button 
      className={`${baseStyles} ${variants[variant]} ${fullWidth ? 'w-full' : ''} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
};