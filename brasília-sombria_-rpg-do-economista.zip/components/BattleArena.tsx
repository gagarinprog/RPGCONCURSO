import React, { useState, useEffect, useRef } from 'react';
import { Quest, CombatPhase, CombatRound } from '../types';
import { HealthBar } from './HealthBar';
import { Button } from './Button';
import { Shield, Sword, AlertTriangle, Scroll, Skull, MapPin } from 'lucide-react';

interface BattleArenaProps {
  quest: Quest;
  onVictory: () => void;
  onDefeat: () => void;
}

export const BattleArena: React.FC<BattleArenaProps> = ({ quest, onVictory, onDefeat }) => {
  const [currentRoundIndex, setCurrentRoundIndex] = useState(0);
  const [combatPhase, setCombatPhase] = useState<CombatPhase>(CombatPhase.NARRATIVE);
  const [playerHP, setPlayerHP] = useState(100);
  const [bossHP, setBossHP] = useState(quest.boss.hp);
  const [feedback, setFeedback] = useState<{ isCorrect: boolean; damage: number } | null>(null);
  const [shake, setShake] = useState(false);

  // References for scrolling or focus
  const narrativeRef = useRef<HTMLDivElement>(null);

  const currentRound: CombatRound = quest.combat_rounds[currentRoundIndex];
  const maxBossHP = useRef(quest.boss.hp).current;

  useEffect(() => {
    if (playerHP <= 0) {
      setTimeout(onDefeat, 1000);
    } else if (bossHP <= 0) {
      setTimeout(onVictory, 1000);
    }
  }, [playerHP, bossHP, onDefeat, onVictory]);

  const handleAnswer = (answer: 'CERTO' | 'ERRADO') => {
    const isCorrect = answer === currentRound.question.correct_answer;
    
    setFeedback({
      isCorrect,
      damage: isCorrect ? currentRound.question.damage_on_hit : currentRound.question.damage_on_miss
    });

    if (isCorrect) {
      // Player hits Boss
      setBossHP(prev => Math.max(0, prev - currentRound.question.damage_on_hit));
    } else {
      // Boss hits Player
      setShake(true);
      setTimeout(() => setShake(false), 500);
      setPlayerHP(prev => Math.max(0, prev - currentRound.question.damage_on_miss));
    }

    setCombatPhase(CombatPhase.RESOLUTION);
  };

  const nextPhase = () => {
    if (bossHP <= 0) return; // Victory pending handled by effect
    if (playerHP <= 0) return; // Defeat pending

    if (currentRoundIndex < quest.combat_rounds.length - 1) {
      setCurrentRoundIndex(prev => prev + 1);
      setCombatPhase(CombatPhase.NARRATIVE);
      setFeedback(null);
    } else {
      onVictory();
    }
  };

  return (
    <div className={`w-full max-w-5xl mx-auto p-4 md:p-6 ${shake ? 'animate-shake' : ''}`}>
      
      {/* Header / Environment */}
      <div className="relative mb-8 rounded-xl overflow-hidden shadow-2xl border-2 border-slate-700">
        {quest.imageUrl ? (
          <>
            <img 
              src={quest.imageUrl} 
              alt={quest.boss.name} 
              className="w-full h-64 md:h-80 object-cover opacity-60"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-900/60 to-transparent"></div>
          </>
        ) : (
          <div className="w-full h-48 bg-slate-900 flex items-center justify-center">
            <span className="text-slate-600 italic">Visualizando o horror...</span>
          </div>
        )}
        
        <div className="absolute bottom-0 left-0 p-6 w-full">
           <div className="flex justify-between items-end">
              <div>
                <div className="flex items-center gap-2 mb-2">
                   <span className="px-3 py-1 bg-amber-600/80 text-white text-xs font-bold rounded uppercase flex items-center gap-1">
                      <MapPin className="w-3 h-3" /> Estágio {quest.stage_number}
                   </span>
                   {quest.is_boss_battle && (
                     <span className="px-3 py-1 bg-red-600/80 text-white text-xs font-bold rounded uppercase animate-pulse">
                        BOSS BATTLE
                     </span>
                   )}
                </div>
                <h2 className="text-3xl md:text-5xl font-bold text-white mb-2 drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)] rpg-font">
                  {quest.quest_title}
                </h2>
                <p className="text-slate-200 text-sm md:text-base max-w-2xl drop-shadow-md">
                  {quest.environment_desc}
                </p>
              </div>
           </div>
        </div>
      </div>

      {/* Battle Status (Health Bars) */}
      <div className="flex flex-col md:flex-row justify-between items-end mb-8 gap-6 bg-slate-900/50 p-4 rounded-lg border border-slate-800">
        <div className="w-full md:w-1/2">
          <div className="flex items-center gap-2 mb-2">
            <div className="p-2 bg-blue-900 rounded-full border border-blue-500">
              <Shield className="w-6 h-6 text-blue-300" />
            </div>
            <span className="text-xl font-bold text-blue-300 rpg-font">Herói Concurseiro</span>
          </div>
          <HealthBar current={playerHP} max={100} label="HP" color="bg-blue-600" />
        </div>

        <div className="w-full md:w-1/2 flex flex-col items-end">
          <div className="flex items-center gap-2 mb-2">
            <span className="text-xl font-bold text-red-400 rpg-font text-right">{quest.boss.name}</span>
            <div className="p-2 bg-red-900 rounded-full border border-red-500">
              <Skull className="w-6 h-6 text-red-300" />
            </div>
          </div>
          <HealthBar current={bossHP} max={maxBossHP} label="INIMIGO" color="bg-red-600" isRightAligned />
          <div className="text-xs text-red-300 mt-1 uppercase tracking-wider">
            Fraqueza: {quest.boss.weakness}
          </div>
        </div>
      </div>

      {/* Main Game Area */}
      <div className="bg-slate-900 border border-slate-600 rounded-lg p-6 shadow-[0_0_50px_rgba(0,0,0,0.5)] min-h-[300px] flex flex-col justify-center relative overflow-hidden">
        
        {/* Phase: Narrative */}
        {combatPhase === CombatPhase.NARRATIVE && (
          <div className="text-center animate-fade-in" ref={narrativeRef}>
            <div className="inline-block p-4 mb-6 bg-slate-800 rounded-full border border-slate-600">
              <Scroll className="w-8 h-8 text-amber-400" />
            </div>
            <h3 className="text-2xl font-bold text-amber-100 mb-6 rpg-font">
              {quest.is_boss_battle ? `Rodada Mortal ${currentRound.round_id}` : `Desafio ${currentRound.round_id}`}
            </h3>
            <p className="text-lg md:text-xl text-slate-300 leading-relaxed max-w-2xl mx-auto mb-8 font-serif">
              "{currentRound.narrative}"
            </p>
            <Button onClick={() => setCombatPhase(CombatPhase.PLAYER_TURN)} className="mt-4" fullWidth={false}>
              Enfrentar
            </Button>
          </div>
        )}

        {/* Phase: Player Turn (Question) */}
        {combatPhase === CombatPhase.PLAYER_TURN && (
          <div className="animate-fade-in">
            <div className="flex items-center justify-center gap-2 mb-4 text-amber-500 font-bold uppercase tracking-widest text-sm">
              <Sword className="w-4 h-4" /> Questão {currentRound.round_id}
            </div>
            <div className="bg-slate-800 p-6 md:p-8 rounded border border-slate-600 mb-8 shadow-inner">
              <p className="text-lg md:text-xl font-medium text-white leading-relaxed">
                <span className="text-purple-400 font-bold mr-2">[JULGUE O ITEM]</span>
                {currentRound.question.statement}
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-xl mx-auto">
              <Button 
                variant="success" 
                onClick={() => handleAnswer('CERTO')}
                className="h-16 text-xl"
              >
                CERTO
              </Button>
              <Button 
                variant="danger" 
                onClick={() => handleAnswer('ERRADO')}
                className="h-16 text-xl"
              >
                ERRADO
              </Button>
            </div>
          </div>
        )}

        {/* Phase: Resolution */}
        {combatPhase === CombatPhase.RESOLUTION && feedback && (
          <div className="text-center animate-fade-in">
            <div className={`mb-6 p-4 rounded-lg inline-block border-2 ${feedback.isCorrect ? 'bg-emerald-900/50 border-emerald-500 text-emerald-300' : 'bg-red-900/50 border-red-500 text-red-300'}`}>
              <h3 className="text-3xl font-bold rpg-font mb-2">
                {feedback.isCorrect ? "ACERTO CRÍTICO!" : "ERRO FATAL!"}
              </h3>
              <p className="text-xl">
                {feedback.isCorrect 
                  ? `Você desferiu ${feedback.damage} de dano lógico!` 
                  : `A ignorância golpeou você em ${feedback.damage} pontos!`}
              </p>
            </div>

            <div className="bg-slate-800/80 p-6 rounded text-left border-l-4 border-amber-500 mb-8">
              <h4 className="text-amber-500 font-bold mb-2 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5" /> Gabarito Comentado
              </h4>
              <p className="text-slate-300 leading-relaxed">
                {currentRound.question.explanation}
              </p>
            </div>

            <Button onClick={nextPhase} variant="secondary">
              {currentRoundIndex < quest.combat_rounds.length - 1 ? "Próxima Questão" : "Finalizar Embate"}
            </Button>
          </div>
        )}
      </div>
    </div>
  );
};