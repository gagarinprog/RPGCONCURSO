import React from 'react';

interface HealthBarProps {
  current: number;
  max: number;
  label: string;
  color?: string;
  isRightAligned?: boolean;
}

export const HealthBar: React.FC<HealthBarProps> = ({ 
  current, 
  max, 
  label, 
  color = "bg-red-600",
  isRightAligned = false 
}) => {
  const percentage = Math.max(0, Math.min(100, (current / max) * 100));

  return (
    <div className={`w-full max-w-md ${isRightAligned ? 'text-right' : 'text-left'}`}>
      <div className="flex justify-between mb-1 text-sm font-bold text-slate-300 rpg-font tracking-widest uppercase">
        <span>{isRightAligned ? `${current}/${max}` : label}</span>
        <span>{isRightAligned ? label : `${current}/${max}`}</span>
      </div>
      <div className="h-4 bg-slate-900 border border-slate-700 relative overflow-hidden rounded-sm shadow-inner">
        <div 
          className={`h-full transition-all duration-500 ease-out ${color} shadow-[0_0_10px_rgba(0,0,0,0.5)]`}
          style={{ width: `${percentage}%` }}
        />
        {/* Gloss effect */}
        <div className="absolute top-0 left-0 w-full h-1/2 bg-white opacity-10 pointer-events-none"></div>
      </div>
    </div>
  );
};