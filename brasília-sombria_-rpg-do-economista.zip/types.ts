export interface Boss {
  name: string;
  visual_archetype: string;
  hp: number;
  weakness: string;
  special_ability: string;
}

export interface Question {
  statement: string;
  type: 'CERTO_ERRADO';
  correct_answer: 'CERTO' | 'ERRADO';
  damage_on_hit: number;
  damage_on_miss: number;
  explanation: string;
}

export interface CombatRound {
  round_id: number;
  narrative: string;
  question: Question;
}

export interface Loot {
  item_name: string;
  xp_reward: number;
}

export interface Quest {
  quest_id: string;
  quest_title: string;
  environment_desc: string;
  boss: Boss;
  combat_rounds: CombatRound[];
  loot: Loot;
  imageUrl?: string; // Base64 image
  is_boss_battle: boolean;
  stage_number: number;
}

export enum GameState {
  MENU = 'MENU',
  LOADING = 'LOADING',
  COMBAT = 'COMBAT',
  VICTORY = 'VICTORY',
  DEFEAT = 'DEFEAT',
  ERROR = 'ERROR',
  CAMPAIGN_MAP = 'CAMPAIGN_MAP' // New state for showing progress
}

export enum CombatPhase {
  NARRATIVE = 'NARRATIVE',
  PLAYER_TURN = 'PLAYER_TURN', 
  RESOLUTION = 'RESOLUTION', 
}